import{s}from"../chunks/scheduler.DtGJeGpk.js";import{S as t,i as e}from"../chunks/index.DEgs2rZ3.js";class l extends t{constructor(o){super(),e(this,o,null,null,s,{})}}export{l as component};
