const g=""+new URL("../assets/github.BsLkggKK.png",import.meta.url).href;export{g};
